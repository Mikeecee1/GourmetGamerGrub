//exports images as an array 

import category1 from './burger.jpg';
import category2 from './nachos.jpg';
import category3 from './cakes.jpg';
import category4 from './milkshake.jpg';

const imgArray = [category1, category2, category3, category4];

export default imgArray