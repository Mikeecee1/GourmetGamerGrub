import { render, screen } from '@testing-library/react';
import App from './App';


// test('renders learn react link', () => {
//   render(<App />);
//   const linkElement = screen.getByText(/learn react/i);
//   expect(linkElement).toBeInTheDocument();
// });


test("adds item to basket", () => {

})

test("removes item from basket", () => {

})

test("increments in basket", () =>{

})

test("decrements item in basket", () =>{

})

test("Updates total correctly when item added", () =>{

})

test("Updates total correctly when item removed", () => {
  
})

