//exports images as an array 

import burger from './burger.jpg';
import pizza from './pizza.jpg';
import fries from './fries.jpg';
import wings from './wings.jpg';
import mario from './mario_cakes.jpg';
import smoothie from './smoothie.jpg';
import milkshake from './milkshake.jpg';
import ammo from './ammo_crate.jpg';
import cake from './cakes.jpg';
import assasin from './assasin.jpg';

const imgArray = [burger, pizza, fries, wings, mario, smoothie, milkshake, cake, ammo, assasin];

export default imgArray